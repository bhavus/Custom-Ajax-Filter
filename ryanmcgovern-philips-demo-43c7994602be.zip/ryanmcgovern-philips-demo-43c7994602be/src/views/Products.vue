<template>
  <div class="wrapper">
    <div class="container">
      <BaseLogo />
      <BaseHome>
        <font-awesome-icon :icon="['fal', 'chevron-left']" />
        <span>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="15"
            height="15"
            viewBox="0 0 15 15"
          >
            <path
              id="Path_43"
              data-name="Path 43"
              d="M227.288,226.153h-.854v7.467a.421.421,0,0,1-.413.426h-3.4a.22.22,0,0,1-.216-.223v-4.166a.22.22,0,0,0-.216-.223H218a.22.22,0,0,0-.216.223v4.166a.22.22,0,0,1-.216.223h-3.4a.421.421,0,0,1-.413-.426v-7.467H212.9a.319.319,0,0,1-.2-.557l7.192-6.472a.3.3,0,0,1,.4,0l7.192,6.472A.319.319,0,0,1,227.288,226.153Z"
              transform="translate(-212.596 -219.046)"
              fill="#fff"
            />
          </svg>
        </span>
        <span>Home</span>
      </BaseHome>
      <Slider class="slider-wrapper" />
      <BaseButton
        @buttonEvent="showComparisonModal"
        buttonClass="blue-bright chevron-right"
      >
        Compare the range
        <font-awesome-icon :icon="['fal', 'chevron-right']" />
      </BaseButton>
      <Modal v-if="showComparison" @close="showComparison = false">
        <img
          :src="require('../assets/images/Home_extras/comparrison-table.png')"
        />
      </Modal>
      <div class="product-panel">
        <p class="font-large product-title"></p>
        <p class="font-medium-lg product-sku"></p>
        <div class="product-bottom">
          <p class="font-medium-lg product-cat"></p>
          <a class="button blue-dark chevron-right product-panel-link" href="#">
            See product detail
            <font-awesome-icon :icon="['fal', 'chevron-right']" />
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Slider from '@/components/Slider.vue'
import Modal from '@/components/Modal.vue'

export default {
  name: 'Products',
  data() {
    return {
      showComparison: false
    }
  },
  components: {
    Slider,
    Modal
  },
  methods: {
    showComparisonModal() {
      this.showComparison = !this.showComparison
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../assets/sass/app.scss';

.wrapper {
  height: 100%;
  display: flex;
  align-items: center;
  background: linear-gradient(
    160deg,
    map-get($colours, 'v-dark-blue') 0%,
    map-get($colours, 'dark-blue') 100%
  );
}

.slider-wrapper {
  display: flex;
  align-items: center;
  height: 100%;
}

.logo {
  position: absolute;
}

.blue-bright {
  position: absolute;
  bottom: 4rem;
  z-index: 99;
}

.blue-dark {
  position: absolute;
  top: 3rem;
  right: 4rem;
  z-index: 99;
}

.product-panel {
  position: absolute;
  text-align: center;
  bottom: 0;
  min-height: 250px;
  max-width: 320px;
  min-width: 320px;
  padding: 3rem;
  color: map-get($colours, 'white');
  background: linear-gradient(
    138deg,
    rgba(#0a55a3, 0.8) 0%,
    rgba(#0097d0, 0.8) 100%
  );
  left: 50%;
  transform: translateX(-50%);
  z-index: 99;

  .blue-dark {
    position: static;
  }
}

.product-title {
  margin-bottom: 1rem;
  transition: all 0.6s linear;
}

.product-sku {
  color: map-get($colours, 'v-light-blue');
  transition: all 0.6s linear;
}
</style>
