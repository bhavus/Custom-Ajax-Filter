<template>
  <div class="wrapper">
    <div class="container">
      <BaseLogo />
      <BaseHome>
        <font-awesome-icon :icon="['fal', 'chevron-left']" />
        <span>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="15"
            height="15"
            viewBox="0 0 15 15"
          >
            <path
              id="Path_43"
              data-name="Path 43"
              d="M227.288,226.153h-.854v7.467a.421.421,0,0,1-.413.426h-3.4a.22.22,0,0,1-.216-.223v-4.166a.22.22,0,0,0-.216-.223H218a.22.22,0,0,0-.216.223v4.166a.22.22,0,0,1-.216.223h-3.4a.421.421,0,0,1-.413-.426v-7.467H212.9a.319.319,0,0,1-.2-.557l7.192-6.472a.3.3,0,0,1,.4,0l7.192,6.472A.319.319,0,0,1,227.288,226.153Z"
              transform="translate(-212.596 -219.046)"
              fill="#fff"
            />
          </svg>
        </span>
        <span>Back to home</span>
      </BaseHome>
      <header class="test-header">
        <h1 class="font-large test-title">
          It’s most important to me that my shaver…
        </h1>
        <p class="test-sub-title font-medium-lg">Choose one</p>
      </header>
      <div class="test-steps-count">
        <span class="font-medium-lg">1/2</span>
      </div>
      <div class="test-choices">
        <label class="choice">
          <div class="checkbox-wrap">
            <input
              class="checkbox"
              @change="getSelectedOption"
              id="choices"
              type="radio"
              v-model="choice"
              value="1"
            />
            <span class="custom-checkbox"></span>
          </div>
          <span class="label-text font-medium-lg">
            Is Easy and
            <br />Comfortable to use
          </span>
        </label>
        <label class="choice">
          <div class="checkbox-wrap">
            <input
              class="checkbox"
              @change="getSelectedOption"
              id="choices"
              type="radio"
              v-model="choice"
              value="2"
            />
            <span class="custom-checkbox"></span>
          </div>
          <span class="label-text font-medium-lg">Is Fast and Efficient</span>
        </label>
        <label class="choice">
          <div class="checkbox-wrap">
            <input
              class="checkbox"
              @change="getSelectedOption"
              id="choices"
              type="radio"
              v-model="choice"
              value="3"
            />
            <span class="custom-checkbox"></span>
          </div>
          <span class="label-text font-medium-lg">
            Will protect my
            <br />sensitive skin from <br />irritation
          </span>
        </label>
        <label class="choice">
          <div class="checkbox-wrap">
            <input
              class="checkbox"
              @change="getSelectedOption"
              id="choices"
              type="radio"
              v-model="choice"
              value="4"
            />
            <span class="custom-checkbox"></span>
          </div>
          <span class="label-text font-medium-lg">
            Delivers the best
            <br />experience with <br />ultimate closeness
          </span>
        </label>
      </div>
      <router-link
        v-if="choice != ''"
        class="button white chevron-right"
        :to="{
          name: 'result',
          params: { id: parseInt(getSelectedOption()) }
        }"
      >
        Next
        <font-awesome-icon :icon="['fal', 'chevron-right']" />
      </router-link>
    </div>
  </div>
</template>

<script>
export default {
  name: 'TakeTest',
  data() {
    return {
      choice: ''
    }
  },
  methods: {
    getSelectedOption() {
      return this.choice
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../assets/sass/app.scss';

.wrapper {
  background: linear-gradient(
    126deg,
    map-get($colours, 'dark-blue') 0%,
    map-get($colours, 'bright-blue') 100%
  );
  height: 100%;
}

.logo {
  position: absolute;
}

.blue-dark {
  position: absolute;
  top: 3rem;
  right: 4rem;
  z-index: 99;
}

.test-header {
  max-width: 440px;
  padding-top: 7rem;
  margin: 0 auto;
  text-align: center;
}

.test-title {
  color: map-get($colours, 'white');
  font-weight: normal;
  margin-top: 0;
  line-height: 3.8rem;
  margin-bottom: 1rem;
}

.test-sub-title {
  color: map-get($colours, 'light-blue');
  margin-bottom: 4rem;
}

.test-steps-count {
  color: map-get($colours, 'white');
  border-radius: 50%;
  background-color: map-get($colours, 'dark-blue');
  margin: 0 auto;
  height: 7rem;
  width: 7rem;
  text-align: center;
  line-height: 7rem;
}

.test-choices {
  max-width: 950px;
  margin: 4rem auto 0;
  width: 100%;
  display: flex;
  justify-content: space-between;
}

.choice {
  flex: 1 1 25%;
}

.checkbox-wrap {
  cursor: pointer;
  display: flex;
  position: relative;
  user-select: none;
  margin-bottom: 2.4rem;

  input {
    &:checked {
      ~ .custom-checkbox {
        &:after {
          display: block;
        }
      }
    }
  }

  .custom-checkbox {
    &:after {
      content: '';
      width: 1.4rem;
      height: 3rem;
      border: solid map-get($colours, 'white');
      border-width: 0 0.4rem 0.4rem 0;
      left: 50%;
      top: 50%;
      transform: rotate(40deg);
      margin-top: -1.8rem;
      margin-left: -0.7rem;
    }
  }
}

.checkbox {
  cursor: pointer;
  height: 0;
  opacity: 0;
  position: absolute;
  width: 0;
}

.custom-checkbox {
  border: 0.5rem solid map-get($colours, 'white');
  border-radius: 0.5rem;
  height: 5rem;
  position: relative;
  right: 0;
  width: 5rem;
  margin: 0 auto;

  &:after {
    content: '';
    display: none;
    position: absolute;
  }
}

.label-text {
  color: map-get($colours, 'white');
  display: block;
  text-align: center;
}

.white {
  position: absolute;
  right: 4rem;
  bottom: 4rem;
}
</style>
