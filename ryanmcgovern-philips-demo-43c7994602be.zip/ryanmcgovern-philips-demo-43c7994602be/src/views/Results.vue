<template>
  <div class="wrapper">
    <div class="container">
      <BaseLogo />
      <div class="top-button">
        <BaseHome>
          <font-awesome-icon :icon="['fal', 'chevron-left']" />
          <span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="15"
              height="15"
              viewBox="0 0 15 15"
            >
              <path
                id="Path_43"
                data-name="Path 43"
                d="M227.288,226.153h-.854v7.467a.421.421,0,0,1-.413.426h-3.4a.22.22,0,0,1-.216-.223v-4.166a.22.22,0,0,0-.216-.223H218a.22.22,0,0,0-.216.223v4.166a.22.22,0,0,1-.216.223h-3.4a.421.421,0,0,1-.413-.426v-7.467H212.9a.319.319,0,0,1-.2-.557l7.192-6.472a.3.3,0,0,1,.4,0l7.192,6.472A.319.319,0,0,1,227.288,226.153Z"
                transform="translate(-212.596 -219.046)"
                fill="#fff"
              />
            </svg>
          </span>
          <span>Back to home</span>
        </BaseHome>
      </div>
      <header class="result-header">
        <h1 class="font-large result-title">Your matches</h1>
      </header>

      <Matches />
      <div class="bottom-button">
        <router-link class="button blue-dark chevron-left" to="/test">
          <font-awesome-icon :icon="['fal', 'chevron-left']" />Back
        </router-link>
      </div>
    </div>
  </div>
</template>

<script>
import Matches from '@/components/Matches.vue'

export default {
  name: 'Results',
  components: {
    Matches
  }
}
</script>

<style lang="scss" scoped>
@import '../assets/sass/app.scss';

.wrapper {
  height: 100%;
  display: flex;
  align-items: center;
  background: linear-gradient(
    160deg,
    map-get($colours, 'v-dark-blue') 0%,
    map-get($colours, 'dark-blue') 100%
  );
}

.logo {
  position: absolute;
}

.result-header {
  max-width: 440px;
  padding-top: 7rem;
  margin: 0 auto;
  text-align: center;
}

.result-title {
  color: map-get($colours, 'white');
  font-weight: normal;
  margin-top: 0;
  line-height: 3.8rem;
  margin-bottom: 1rem;
}

.top-button {
  .blue-dark {
    position: absolute;
    top: 3rem;
    right: 4rem;
    z-index: 99;
  }
}

.bottom-button {
  .blue-dark {
    position: absolute;
    bottom: 4rem;
    left: 4rem;
    z-index: 99;
  }
}
</style>
