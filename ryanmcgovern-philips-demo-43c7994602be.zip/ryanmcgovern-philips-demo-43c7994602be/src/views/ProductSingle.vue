<template>
  <div class="wrapper">
    <!-- Left panel -->
    <aside class="left-panel">
      <BaseLogo />
      <p
        class="font-large product-title"
        v-html="title || getProduct(productId).title"
      ></p>
      <p
        class="font-large product-title"
        v-html="subtitle || getProduct(productId).subtitle"
      ></p>
      <p v-if="showSKU" class="font-medium-lg product-sku">
        {{ getProduct(productId).sku }}
      </p>
      <div
        class="product-description"
        v-html="featureDescription || getProduct(productId).description"
      ></div>
      <div class="product-buttons">
        <BaseButton
          v-if="getProduct(productId).video"
          @buttonEvent="showVideoModal"
          buttonClass="blue"
        >
          Play product video
          <font-awesome-icon :icon="['fal', 'chevron-right']" />
        </BaseButton>
        <BaseButton
          @buttonEvent="showComparisonModal"
          buttonClass="blue-bright"
        >
          Compare the range
          <font-awesome-icon :icon="['fal', 'chevron-right']" />
        </BaseButton>
        <div class="button blue-dark" v-if="isActive" @click="resetProduct()">
          <font-awesome-icon :icon="['fal', 'chevron-left']" />
          <span>Back</span>
        </div>
        <p
          v-html="disclaimer || getProduct(productId).disclaimer"
          class="font-xsmall"
        ></p>
      </div>
      <Modal v-if="showVideo" @close="showVideo = false">
        <video v-if="getProduct(productId).video" autoplay>
          <source
            :src="require('../assets/videos/' + getProduct(productId).video)"
            type="video/mp4"
          />
        </video>
      </Modal>
      <Modal v-if="showComparison" @close="showComparison = false">
        <img
          :src="require('../assets/images/Home_extras/comparrison-table.png')"
        />
      </Modal>
    </aside>
    <!-- END. Left panel -->
    <!-- Right panel -->
    <div
      class="right-panel"
      :class="{ active: isActive }"
      :style="{
        backgroundImage: background || upDateProductBackground
      }"
    >
      <Halo :featuresCount="`circle-container-` + getFeaturesLength()">
        <Feature
          ref="circles"
          v-for="(feature, key, index) in reverseFeatures()"
          :key="index"
          :feature="feature"
          @changeProductData="upDateProduct"
          :class="{ active: isActiveFeature }"
        ></Feature>
      </Halo>
      <div class="product-image">
        <img
          :src="
            require('../assets/images/' + getProduct(productId).sliderImage) +
              ''
          "
        />
      </div>
      <div class="product-notice">
        <p>Touch icon to explore feature</p>
      </div>
      <div class="product-home">
        <BaseHome>
          <font-awesome-icon :icon="['fal', 'chevron-left']" />
          <span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="15"
              height="15"
              viewBox="0 0 15 15"
            >
              <path
                id="Path_43"
                data-name="Path 43"
                d="M227.288,226.153h-.854v7.467a.421.421,0,0,1-.413.426h-3.4a.22.22,0,0,1-.216-.223v-4.166a.22.22,0,0,0-.216-.223H218a.22.22,0,0,0-.216.223v4.166a.22.22,0,0,1-.216.223h-3.4a.421.421,0,0,1-.413-.426v-7.467H212.9a.319.319,0,0,1-.2-.557l7.192-6.472a.3.3,0,0,1,.4,0l7.192,6.472A.319.319,0,0,1,227.288,226.153Z"
                transform="translate(-212.596 -219.046)"
                fill="#fff"
              />
            </svg>
          </span>
          <span>Home</span>
        </BaseHome>
      </div>
    </div>
    <!-- END. Right panel -->
  </div>
</template>

<script>
import Halo from '@/components/ProductHalo.vue'
import Feature from '@/components/ProductFeature.vue'
import Modal from '@/components/Modal.vue'
import { mapState } from 'vuex'

export default {
  name: 'ProductSingle',

  components: {
    Halo,
    Feature,
    Modal
  },

  data() {
    return {
      showVideo: false,
      showComparison: false,
      showSKU: true,
      title: '',
      subtitle: '',
      disclaimer: '',
      isActive: false,
      isActiveFeature: false,
      featureDescription: '',
      background: 'linear-gradient(142deg, #003478 0%, #0066a1 100%'
    }
  },

  computed: {
    productId() {
      return parseInt(this.$route.params.id)
    },

    getProduct() {
      return this.$store.getters.getProductById
    },

    ...mapState(['products'])
  },

  methods: {
    //modals
    showVideoModal() {
      this.showVideo = !this.showVideo
    },

    showComparisonModal() {
      this.showComparison = !this.showComparison
    },

    //add active class
    addActiveClass() {
      this.isActive = true
    },

    // content modifications outside of loop
    upDateProductTitle(e) {
      return (this.title = e.item.title)
    },

    upDateProductSubttle(e) {
      return (this.subtitle = e.item.subtitle)
    },

    upDateProductBackground(e) {
      return (this.background =
        'url(' +
        require('../assets/images/' + e.item.featureBackground + '') +
        ')')
    },

    upDateFeatureDescription(e) {
      return (this.featureDescription = e.item.featureDescription)
    },

    upDateProduct: function(e) {
      this.showSKU = false
      this.upDateProductTitle(e)
      this.upDateProductSubttle(e)
      this.upDateProductBackground(e)
      this.upDateFeatureDescription(e)
      this.addActiveClass()
    },

    // count the number of features for each product
    getFeaturesLength() {
      return this.getProduct(this.productId).features.length.toString()
    },

    reverseFeatures() {
      return this.getProduct(this.productId)
        .features.slice()
        .reverse()
    },

    deactivateProduct: function() {
      this.isActiveFeature = false
    },

    resetProduct() {
      this.isActive = false
      this.showSKU = true
      this.title = this.getProduct(this.productId).title
      this.subtitle = this.getProduct(this.productId).subtitle
      this.featureDescription = this.getProduct(this.productId).description
      this.background = 'linear-gradient(142deg, #003478 0%, #0066a1 100%'

      let items = document.querySelectorAll('.circle-item')
      let productFeature = document.querySelectorAll('.product-feature')

      productFeature.forEach(element => {
        element.style.display = 'block'
      })

      items.forEach(element => {
        element.classList.remove('active')
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../assets/sass/app.scss';

.wrapper {
  display: flex;
  height: 100%;
}

.left-panel {
  width: 400px;
  padding: 0 4rem 4rem;
  color: map-get($colours, 'white');
  background: linear-gradient(
    149deg,
    map-get($colours, 'v-dark-blue') 0%,
    map-get($colours, 'dark-blue') 100% 100%
  );

  .button {
    margin-bottom: 2rem;
    display: table;
  }

  .blue,
  .blue-bright {
    min-width: 190px;

    svg {
      margin-left: 1rem;
    }
  }
}

.right-panel {
  width: 624px;
  background-size: cover;
  background-repeat: no-repeat;
  background-position: 50%;
  background-image: linear-gradient(
    142deg,
    map-get($colours, 'dark-blue') 0%,
    map-get($colours, 'bright-blue') 100%
  );
  opacity: 1;
  position: relative;
  display: flex;
  align-items: center;

  &.active {
    .circle-container {
      background: linear-gradient(
        180deg,
        rgba(map-get($colours, 'circle-dark'), 0.6) 0%,
        rgba(map-get($colours, 'circle-light'), 0.6) 100%
      );
    }
  }
}

.product-title {
  line-height: 3.8rem;
  margin-bottom: 0;
}

.product-sku {
  margin-top: 1rem;
  color: map-get($colours, 'v-light-blue');
}

.product-description {
  line-height: 2.2rem;

  /deep/ p {
    font-size: 1.7rem;
    margin-bottom: 1rem;
  }

  /deep/ ul {
    font-size: 1.7rem;
    margin: 0;
    padding: 0 0 0 1.5rem;

    li {
      line-height: 2.5rem;
    }
  }
}

.product-buttons {
  position: absolute;
  bottom: 2rem;
}

.product-notice {
  position: absolute;
  top: 0;
  background-color: map-get($colours, 'white');
  max-width: 135px;
  border-bottom-left-radius: 0.5rem;
  border-bottom-right-radius: 0.5rem;
  left: 1rem;
  text-align: center;
  padding: 1rem;
  border: 1px solid map-get($colours, 'v-dark-blue');
  border-top: 0;

  p {
    margin: 0;
  }
}

.product-home {
  position: absolute;
  top: 2rem;
  right: 2rem;
}

.product-image {
  border-radius: 50%;
  position: absolute;
  max-height: 340px;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);

  img {
    border-radius: 50%;
    max-height: 340px;
  }
}
</style>
