<template>
  <div class="home">
    <div class="container">
      <BaseLogo />
      <div class="cards">
        <div class="card">
          <div class="inner">
            <div class="card-header">
              <p class="font-medium">{{ getProduct(1).title }}</p>
            </div>
            <div class="card-button">
              <router-link
                class="button blue"
                :to="{
                  name: 'product',
                  params: { id: getProduct(1).productId }
                }"
              >
                Find out more
                <font-awesome-icon :icon="['fal', 'chevron-right']" />
              </router-link>
            </div>
            <div class="card-body">
              <img
                :src="
                  require('../assets/images/' +
                    getProduct(1).homePageCutImage) + ''
                "
              />
            </div>
          </div>
        </div>
        <div class="card">
          <div class="inner">
            <div class="card-header">
              <p class="font-medium">{{ getProduct(2).title }}</p>
            </div>
            <div class="card-button">
              <router-link
                class="button blue"
                :to="{
                  name: 'product',
                  params: { id: getProduct(2).productId }
                }"
              >
                Find out more
                <font-awesome-icon :icon="['fal', 'chevron-right']" />
              </router-link>
            </div>
            <div class="card-body">
              <img
                :src="
                  require('../assets/images/' +
                    getProduct(2).homePageCutImage) + ''
                "
              />
            </div>
          </div>
        </div>
        <div class="card">
          <div class="inner">
            <div class="card-header">
              <p class="font-medium">Explore the full range</p>
            </div>
            <div class="card-button">
              <router-link
                class="button blue"
                :to="{
                  name: 'products'
                }"
              >
                Explore
                <font-awesome-icon :icon="['fal', 'chevron-right']" />
              </router-link>
            </div>
            <div class="card-body">
              <img
                :src="require('../assets/images/Home_extras/full-range.png')"
              />
            </div>
          </div>
        </div>
        <div class="card">
          <div class="inner alternate">
            <div class="card-header">
              <p class="font-medium">Which shaver is best for me?</p>
            </div>
            <div class="card-button">
              <router-link
                class="button orange"
                :to="{
                  name: 'test'
                }"
              >
                Take the test
                <font-awesome-icon :icon="['fal', 'chevron-right']" />
              </router-link>
            </div>
            <div class="card-body">
              <div
                class="card-bg-image"
                :style="{ backgroundImage: testProductBackground() }"
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import { mapState } from 'vuex'

export default {
  name: 'Home',
  data() {
    return {
      background: ''
    }
  },
  computed: {
    getProduct() {
      return this.$store.getters.getProductById
    },
    ...mapState(['products'])
  },
  methods: {
    testProductBackground() {
      return (this.background =
        'url(' +
        require('../assets/images/Home_extras/best-for-me.jpg' + '') +
        ')')
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../assets/sass/app.scss';

.home {
  height: 100%;
  background: linear-gradient(
    160deg,
    map-get($colours, 'v-dark-blue') 0%,
    map-get($colours, 'dark-blue') 100%
  );
  padding-bottom: 4rem;
}

.cards {
  display: flex;
  flex-wrap: wrap;
  margin: 0 -1.5rem;
  height: calc(100% - 16rem);
}

.card {
  color: map-get($colours, 'white');
  flex: 0 0 25%;
  max-width: 25%;
  padding: 0 1.5rem;
  height: 100%;
}

.inner {
  background: linear-gradient(
    159deg,
    map-get($colours, 'dark-blue') 0%,
    map-get($colours, 'bright-blue') 100%
  );
  opacity: 1;
  height: 100%;
  max-height: 400px;
}

.alternate {
  background: linear-gradient(159deg, #0a55a3 0%, #0097d0 100%);
}

.card-header {
  min-height: 14rem;
  padding: 3rem 2.5rem 0;
  line-height: 1.25;
}

.card-button {
  padding: 1rem 2.5rem 2.2rem 2.5rem;

  .button {
    svg {
      margin-left: 1rem;
    }
  }
}

.card-body {
  height: 174px;
  position: relative;
  margin-top: 1.5rem;

  img {
    max-width: 80%;
    margin: 0 auto;
    display: block;
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    top: auto;
    margin: 0 auto;
  }
}

.card-bg-image {
  height: 174px;
  background-size: cover;
  background-position: 50%;
  background-repeat: no-repeat;
}
</style>
