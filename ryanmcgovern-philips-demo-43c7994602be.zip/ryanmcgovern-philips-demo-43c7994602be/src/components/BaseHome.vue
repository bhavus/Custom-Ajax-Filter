<template>
  <router-link class="button blue-dark" to="/">
    <slot>
      <font-awesome-icon :icon="['fal', 'chevron-left']" />
      <span>Back to home</span>
    </slot>
  </router-link>
</template>

<script>
export default {
  name: 'BaseHome'
}
</script>

<style lang="scss" scoped></style>
