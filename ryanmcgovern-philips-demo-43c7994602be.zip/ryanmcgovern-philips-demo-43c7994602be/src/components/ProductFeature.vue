<template>
  <li class="circle-item">
    <span
      :class="{ top: checkposition() == true }"
      class="product-feature font-medium-lg"
      v-if="checkposition() == true"
      v-html="feature.item.title"
    ></span>
    <button @click="changeProductData(feature, $event)">
      <div class="product-feature__button">
        <img :src="require('../assets/images/' + feature.item.featureIcon)" />
      </div>
    </button>
    <span
      :class="{ bottom: checkposition() == false }"
      class="product-feature font-medium-lg"
      v-if="checkposition() == false"
      v-html="feature.item.title"
    ></span>
  </li>
</template>

<script>
export default {
  name: 'ProductFeature',

  props: {
    feature: Object
  },

  data() {
    return {
      top: false,
      bottom: false,
      isActive: false
    }
  },

  methods: {
    checkposition() {
      let p = this.feature.item.position
      if (p == 'bottom') return false
      if (p == 'top') return true
    },

    changeProductData: function(feature, event) {
      // Send an event out to the parent component
      this.$emit('changeProductData', feature)

      let items = document.querySelectorAll('.circle-item')
      let productFeature = document.querySelectorAll('.product-feature')

      productFeature.forEach(element => {
        element.style.display = 'none'
      })

      items.forEach(element => {
        element.classList.remove('active')
      })
      event.target.parentElement.classList.add('active')
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../assets/sass/app.scss';

.product-feature {
  position: absolute;
  color: map-get($colours, 'white');
  text-align: center;
  width: 20rem;

  &.top {
    top: -4.4rem;
    left: -8.4rem;
  }

  &.bottom {
    top: 5rem;
    left: -8.4rem;
  }

  &__button {
    display: block;
    height: 100%;
    position: relative;
    width: 100%;

    &:before {
      background-color: map-get($colours, 'brighter-blue');
      border-radius: 50%;
      content: '';
      display: none;
      position: absolute;
      transition: map-get($transitions, 'all');
    }
  }
}
</style>
