<template>
  <ul class="circle-container" :class="featuresCount">
    <slot></slot>
  </ul>
</template>

<script>
export default {
  name: 'ProductHalo',
  props: {
    featuresCount: {
      type: String,
      default: '1'
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../assets/sass/app.scss';
</style>
