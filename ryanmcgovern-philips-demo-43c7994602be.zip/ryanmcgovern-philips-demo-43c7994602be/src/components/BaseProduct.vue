<template>
  <div class="button blue-dark">
    <slot>
      <font-awesome-icon :icon="['fal', 'chevron-left']" />
      <span>Back</span>
    </slot>
  </div>
</template>

<script>
export default {
  name: 'BaseProduct'
}
</script>

<style lang="scss" scoped></style>
