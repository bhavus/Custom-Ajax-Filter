<template>
  <div class="logo">
    <img
      :src="require('../assets/images/Home_extras/lockup.png')"
      width="204"
      height="159"
    />
  </div>
</template>

<script>
export default {
  name: 'BaseLogo'
}
</script>

<style lang="scss" scoped>
.logo {
  margin-bottom: 1rem;

  img {
    margin-top: -1.8rem;
    margin-left: -1.8rem;
  }
}
</style>
