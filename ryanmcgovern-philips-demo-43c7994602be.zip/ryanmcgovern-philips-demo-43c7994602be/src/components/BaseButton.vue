<template>
  <button @click="$emit('buttonEvent')" class="button" :class="buttonClass">
    <slot></slot>
  </button>
</template>

<script>
export default {
  name: 'BaseButton',
  props: {
    buttonClass: {
      type: String,
      default: ''
    }
  }
}
</script>

<style lang="scss" scoped></style>
