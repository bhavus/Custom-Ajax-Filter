<template>
  <swiper :options="swiperOptions">
    <swiper-slide
      class="product"
      v-for="product in products"
      :key="product.productId"
    >
      <router-link
        :to="{
          name: 'product',
          params: { id: product.productId }
        }"
      >
        <img
          :src="require('../assets/images/' + product.sliderImage)"
          :alt="product.title"
        />
        <span class="slider-title">{{ product.title }}</span>
        <span class="slider-sku">{{ product.sku }}</span>
        <span class="slider-desc">{{ product.category }}</span>
        <span class="slider-link">{{ product.productId }}</span>
      </router-link>
    </swiper-slide>
    <div class="swiper-button swiper-button-prev" slot="button-prev">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="23.956"
        height="43.912"
        viewBox="0 0 23.956 43.912"
      >
        <defs></defs>
        <path
          style="fill: none; stroke: #fff; stroke-linecap: round; stroke-linejoin: round; stroke-width: 4px;"
          d="M564.5, 474.469l19.128-19.128L564.5, 436.214"
          transform="translate(585.628 477.297) rotate(180)"
        />
      </svg>
    </div>
    <div class="swiper-button swiper-button-next" slot="button-next">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="23.956"
        height="43.912"
        viewBox="0 0 23.956 43.912"
      >
        <defs></defs>
        <path
          style="fill: none; stroke: #fff; stroke-linecap: round; stroke-linejoin: round; stroke-width: 4px;"
          d="M564.5, 474.469l19.128-19.128L564.5, 436.214"
          transform="translate(-561.672 -433.385)"
        />
      </svg>
    </div>
  </swiper>
</template>

<script>
import 'vue-awesome-swiper/node_modules/swiper/dist/css/swiper.css'
import { swiper, swiperSlide } from 'vue-awesome-swiper'
import { mapState } from 'vuex'

export default {
  name: 'Slider',
  computed: {
    ...mapState(['products'])
  },
  props: {
    centerItemObj: Object
  },
  data() {
    return {
      swiperOptions: {
        slidesPerView: 2,
        spaceBetween: 20,
        centeredSlides: true,
        loop: true,
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        },
        effect: 'coverflow',
        coverflowEffect: {
          rotate: 0,
          stretch: 0,
          depth: 500,
          modifier: 1,
          slideShadows: false
        },
        grabCursor: true,
        parallax: true
      }
    }
  },
  components: {
    swiper,
    swiperSlide
  },
  methods: {
    getCenterItem() {
      // Take some stuff from here....
      let item = this.$el.querySelector('.swiper-slide-active')
      let title = item.querySelector('.slider-title')
      let sku = item.querySelector('.slider-sku')
      let desc = item.querySelector('.slider-desc')
      let id = item.querySelector('.slider-link')

      // ...And put it here
      let productPanel = document.querySelector('.product-panel')
      let productTitle = productPanel.querySelector('.product-title')
      let productSku = productPanel.querySelector('.product-sku')
      let productCat = productPanel.querySelector('.product-cat')
      let ProductLink = productPanel.querySelector('.product-panel-link')

      productTitle.innerHTML = title.innerHTML
      productSku.innerHTML = sku.innerHTML
      productCat.innerHTML = desc.innerHTML
      ProductLink.setAttribute('href', '#/product/' + id.innerHTML)
    },
    changePanelText() {
      let trigger = this.$el.querySelectorAll('.swiper-button')
      trigger.forEach(element => {
        element.addEventListener('click', this.getCenterItem)
      })
    }
  },
  mounted() {
    this.getCenterItem()
    this.changePanelText()
  }
}
</script>

<style lang="scss">
@import '../assets/sass/app.scss';
.slider-title,
.slider-sku,
.slider-desc,
.slider-link {
  display: none;
}

.swiper-button {
  align-items: center;
  display: flex;
  height: 100%;
  margin-top: 0;
  top: 0;
  width: 21rem;

  &-next {
    justify-content: flex-end;
  }

  &-prev {
    justify-content: flex-start;
  }
}
</style>
