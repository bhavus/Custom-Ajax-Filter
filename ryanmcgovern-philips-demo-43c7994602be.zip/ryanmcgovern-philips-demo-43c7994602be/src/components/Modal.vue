<template>
  <transition name="fade">
    <div class="modal-wrapper">
      <div class="modal-inner">
        <button class="modal-close" @click="$emit('close')">
          <font-awesome-icon :icon="['fal', 'times']" />
        </button>
        <div class="modal-header"></div>
        <div class="modal-body">
          <slot></slot>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  name: 'Modal'
}
</script>

<style lang="scss">
@import '../assets/sass/app.scss';
.modal-wrapper {
  transition: opacity 0.3s ease;
  background-color: map-get($colours, 'v-dark-blue');
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  display: flex;
  padding: 3.6rem 2.7rem 2rem;
  z-index: 100;
  color: map-get($colours, 'v-dark-blue');
}

.modal-close {
  position: absolute;
  color: map-get($colours, 'white');
  top: 1rem;
  right: 2.7rem;
  padding: 0;
  appearance: none;
  border: 0;
  background: none;
  outline: 0;
  font-size: 1.9rem;
}

.modal-inner {
  background-color: map-get($colours, 'white');
  max-width: 970px;
  margin: 0 auto;
  height: 100%;
  width: 100%;
}

.modal-body {
  height: 100%;
  position: relative;
  overflow: hidden;

  video {
    width: 100%;
    object-fit: cover;
    height: 100%;
  }

  img {
    height: auto;
    width: 100%;
  }
}

.fade-enter-active,
.fade-leave-active {
  opacity: 1;
}

.fade-enter,
.fade-leave-to {
  opacity: 0;
}
</style>
