<template>
  <div class="results">
    <div
      ref="blah"
      v-for="result in getProducts(results)"
      :key="result.productId"
      class="result-item"
    >
      <img
        :src="require('../assets/images/' + result.sliderImage)"
        :alt="result.name"
      />
      <div class="product-header">
        <p class="product-name">{{ result.title }}</p>
        <p class="font-medium-lg product-sku">{{ result.sku }}</p>
      </div>
      <p class="font-medium-lg product-category">{{ result.category }}</p>
      <router-link
        class="button blue chevron-right"
        :to="{
          name: 'product',
          params: { id: result.productId }
        }"
      >
        Find out more
        <font-awesome-icon :icon="['fal', 'chevron-right']" />
      </router-link>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
  name: 'Matches',
  computed: {
    productId() {
      return parseInt(this.$route.params.id)
    },
    getProducts() {
      return this.$store.getters.getProductSetByIds
    },
    ...mapState(['products'])
  },
  data() {
    return {
      results: []
    }
  },
  methods: {
    getChosenProducts() {
      let id = this.productId
      let result = this.results
      switch (id) {
        case 1:
          result.push(4, 6)
          break
        case 2:
          result.push(5)
          break
        case 3:
          result.push(1, 2, 3)
          break
        case 4:
          result.push(3)
          break
        default:
          result.push(1)
      }
      return result
    }
  },
  mounted() {
    this.getChosenProducts()
  }
}
</script>

<style lang="scss" scoped>
@import '../assets/sass/app.scss';

.results {
  display: flex;
  justify-content: center;
  margin: 0 auto;
  max-width: 850px;
  width: 100%;
}

.result-item {
  flex: 0 0 33.3333%;
  max-width: 33.3333%;
  text-align: center;

  img {
    display: block;
    height: auto;
    margin: 0 auto;
    max-height: 280px;
    max-width: 100%;
  }
}

.product-header {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  min-height: 8.7rem;
}

.product-name {
  align-self: flex-start;
  font-size: 2.2rem;
  margin-bottom: 1rem;
}

.product-name,
.product-category {
  color: map-get($colours, 'white');
}

.product-sku {
  align-self: flex-end;
  color: map-get($colours, 'v-light-blue');
  display: block;
  width: 100%;
}
</style>
