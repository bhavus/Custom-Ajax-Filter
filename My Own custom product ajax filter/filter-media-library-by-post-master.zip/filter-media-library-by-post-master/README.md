# Filter Media Library by Post #
**Contributors:** qlstudio  
**Tags:** Filter, Media, Post  
**Requires at least:** 5.0.0  
**Tested up to:** 5.5.3  
**Stable tag:** 0.0.3  
**License:** GPL3  

Filter the attachment list in the WordPress Media Library by the post they are attached to

## Description ##

Filter the attachment list in the WordPress Media Library by the post they are attached to

## Installation ##

1. Upload the plugin to your plugins directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Enjoy :)

## Screenshots ##

No applicable screenshots

## Frequently Asked Questions ##

None

## Changelog ##

### 0.0.2 ###

* Updated to work with WP 5.5.3

### 0.0.1 ###

* Initial working version

## Upgrade Notice ##

### 0.0.1 ###

* Initial working version
