<template>
  <div id="app">
    <div class="container">
      <nav id="nav" class="nav">
        <router-link to="/">Home</router-link>
        <router-link :to="{name: 'History'}">History</router-link>
      </nav>
      <router-view/>
    </div>
  </div>
</template>

<style lang="sass">
@import '@/assets/sass/app'

</style>
