<template>
  <ul class="table">
    <li class="trow">
      <span class="th tcell">Source currency</span>
      <span class="th tcell">Target currency</span>
      <span class="th tcell">Amount to be converted</span>
      <span class="th tcell">Converted amount</span>
      <span class="th delete">Delete</span>
    </li>
    <TableRow v-for="(row, index) in history" :key="index" :source="row.source" :target="row.target" :amount="row.amount" :converted="row.converted" @deleteRow="deleteRow(index)"></TableRow>
    <li v-if="!history.length" class="tcell empty">History is empty</li>
  </ul>
</template>

<script>
  import TableRow from '@/components/TableRow';

  export default {
    name: 'History',
    components: {
      TableRow,
    },
    data() {
      return {
        // mock data
        history: [
          {
            source: 'Pound Sterling',
            target: 'US Dollar',
            amount: '200',
            converted: '278.19'
          },
          {
            source: 'Brazilian Real',
            target: 'Euro',
            amount: '100',
            converted: '15.35'
          },
        ]
      }
    },
    methods: {
      deleteRow(index) {
        this.history.splice(index, 1);
      }
    },
  }
</script>

<style lang="scss" scoped>

</style>