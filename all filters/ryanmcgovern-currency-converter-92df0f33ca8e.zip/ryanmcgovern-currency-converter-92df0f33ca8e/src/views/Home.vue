<template>
  <div class="currency-converter d-flex">
    <ValidationObserver slim>
    <form class="conversion-form" action="">
      <h1>Currency Converter</h1>
      <div class="overview">
        <div>
          <span>1 </span>
          <span>Pound sterling </span>
          <span>equals</span>
        </div>
        <div>
          <span>1.14 </span>
          <span>Euro</span>
        </div>
        <div>
          <small>12 Feb, 14:26 UTC</small>
        </div>
      </div>
      <div class="form-row">
        <ValidationProvider name="baseAmount" :rules="{required: true, regex: /^\d*\.?\d*$/}" slim v-slot="{ errors, classes }">
        <div :class="classes"> 
          <label for="base_amount">Select base amount</label>
          <input type="text" id="base_amount" name="base_amount" v-model="baseAmount"/>
          <span>{{ errors[0] }}</span>
        </div>
        </ValidationProvider>
        <div>
          <label for="base_currency">Select base currency</label>
          <select @change="updateSourceCurrency" name="base_currency" id="base_currency" v-model="firstCurrency">
            <option v-for="(option, index) in sourceCurrency" :key="index" :value="option.code">
              {{option.name}}
            </option>
          </select>
        </div>
      </div>
      <div class="form-row">
        <ValidationProvider name="targetAmount" :rules="{required: true, regex: /^\d*\.?\d*$/}" slim v-slot="{ errors, classes }"> 
        <div :class="classes">
          <label for="target_amount">Select target amount</label>
          <input type="text" id="target_amount" name="target_amount" v-model="targetAmount"/>
          <span>{{ errors[0] }}</span>
        </div>
        </ValidationProvider>
        <div>
          <label for="target_currency">Select target currency</label>
          <select @change="updateTargetCurrency" name="target_currency" id="target_currency" v-model="secondCurrency">
            <option v-for="(option, index) in targetCurrency" :key="index" :value="option.code">
              {{option.name}}
            </option>
          </select>
        </div>
      </div>
    </form>
    </ValidationObserver>
  </div>
</template>

<script>
import { mapState } from 'vuex'

import { ValidationProvider, ValidationObserver } from 'vee-validate';
import { extend } from 'vee-validate';
import { required, regex } from 'vee-validate/dist/rules';
import { configure } from 'vee-validate';

// Add Vee Validate Classes
configure({
  classes: {
    valid: 'is-valid',
    invalid: 'is-invalid',
    dirty: 'is-dirty'
  }
})

// Extend the error messages
extend('required', {
  ...required,
  message: 'This field can\'t be empty'
});

extend('regex', {
  ...regex,
  message: 'The field can only contain numbers'
});

export default {
  name: 'Home',
  components: {
    ValidationProvider,
    ValidationObserver
  },
  data() {
    return {
      baseAmount: '1.00',
      firstCurrency: 'GBP',
      targetAmount: '0.00',
      secondCurrency: 'EUR'
    }
  },
  methods: {
    // todo 
    updateSourceCurrency() {
      //console.log(this.firstCurrency);
      // this.$store.dispatch('getSourceCurrency', {
      //   code: this.secondCurrency
      // })
    },
    updateTargetCurrency() {
      //console.log(this.firstCurrency);
      // this.$store.dispatch('getTargetCurrency', {
      //   code: this.firstCurrency
      // })
    }
  },
  // populate dropdowns on creation
  created() {
    this.$store.dispatch('getSourceCurrency', {
        code: this.secondCurrency
    }),
    this.$store.dispatch('getTargetCurrency', {
        code: this.firstCurrency
    })
  },
  computed: {
    ...mapState(['sourceCurrency', 'targetCurrency'])
  },
  mounted () {
    
  },
}
</script>
