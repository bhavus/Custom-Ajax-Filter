<?php
// require each individual options script
require_once('options_home.php');
