<main data-css-content="main">
  <div data-css-content="wrapper" data-js-filter="target">
    <?php get_template_part('partials/home/loop'); ?>
  </div>
</main>