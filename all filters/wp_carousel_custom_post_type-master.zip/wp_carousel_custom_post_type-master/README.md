# wp_carousel_custom_post_type

Note!

Our main focus was the carousel Bootstrap 4 with Wordpress using custom post type with text animation. We integrated Boostrap  in the starter theme. it might need some additional stylesheet if you wanna use it.
