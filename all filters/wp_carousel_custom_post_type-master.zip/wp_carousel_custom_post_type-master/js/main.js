jQuery(document).ready(function(){

          jQuery('.navbar').addClass('fixed-top');
          jQuery('.navbar').addClass('navclass-jq');
          jQuery('.navbar').addClass('nav_transparent');
          jQuery('.navbar').removeClass('nav_bg');


});
