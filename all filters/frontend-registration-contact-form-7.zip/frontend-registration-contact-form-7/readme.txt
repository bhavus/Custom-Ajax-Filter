﻿=== Frontend Registration - Contact Form 7 ===
Contributors: pokornydavid
Tags: Contact Form 7, form, forms,registration, contactform7, Woocommerce, woo-commerce fields, Usermeta field, contact form, submit, Contact Forms 7, Contact Form 7 + Registration,Contact Forms, contacted, contacts, integrate Frontend Registration with contact form 7, Change Contact Form 7 in Registration form , signup form
Donate link: http://#/payment/
Requires at least: 5.x.x
Tested up to: 6.1.1
Stable tag: 4.5
License: GPLv3 or later License
Contact Form 7 requires at least: 3.0
Contact Form 7 tested up to: 5.x
Version: 4.5
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Contact Form 7 - Frontend Registration Form.

== Description ==

Contact Form 7 (CF7) is the most reliable WordPress Plugin used by the millions of user. Now a day's so many add-on are available for Contact form 7.

We have created same like one add on for contact from 7 in which you can convert contact from 7 into registration form or signup form for WordPress user.

By using this plugin you can create registration form by which registered user will be register as a subscriber role in WordPress.

You just need to add plugin and select fields for username and email ID from created fields. In order to use this plugin, make sure your Contact Form 7 is activated.

= Contact Form 7 - Frontend Registration Form Features List =

* You can convert your Contact form 7 form into registration form.
* Allows you to set fields for user name and email from admin settings.
* Plugin can work in multiple forms on different page or single page.
* You can select particular user role for the registration from settings.
* You can skip default email of Contact form 7 Pro.

= Contact Form 7 - Frontend Registration Pro 4.9 Plug-in Features =
* We have provide restriction of same name and email with registrations.
* Also provide field for add link of login page if you are create custom login page.
* You can customize your registration mail which will be send to user with registration information.
* Easy understanding all setting from admin side.
* Also you can configured multiple Contact form 7 Pro for registration.
* Ability to set each and every different setting for different forms.
* Now you can set Password field from amdin.
* So User can their own password from frontend registration form. 
* New feature with User meta field. Now you can assign your field to User meta fields , Also If you make extra user meta field then also supports.
* We have also supports Woocommerc Fields, Just make same field in contact for 7 and assign it to perticular Fields of Woocommerce.
* In custome field we have support with ACF fields only. You can assign Text field and Select Field to user page that can manage at the time of registration on contact Form 7.

= For Pro Version Vist Our site =
<strong>[For Contact 7- PayPal Extension Pro](http://www.wpbuilderweb.com/product/frontend-registration-contact-form-7-pro/)</strong>
<strong>[Shop More Products](http://www.wpbuilderweb.com/shop/)</strong>

== Plugin Requirement ==

PHP version : 5.3 and latest
WordPress   : Wordpress 5.0 and latest

== Installation ==

1. There are two ways you can install this WordPress Plugin. Either Open https://wordpress.org/plugins/frontend-registration-contact-form-7/, which is the official WordPress Plugins’ directory page, or upload all files manually to your site’s server. click on the download button the page.
2. Now login to your WordPress site and activate the plugin. Then, select ‘edit’ option in ‘Contact Forms’.
3. You will find a tab added to your Contact Form 7 - "Registration Settings"
4. You can set registration fields from here, for all the fields added to your contact form.

== Frequently Asked Questions ==

= Do this plugin use any customization in contact form 7 plugin? = 

No, this plugin does not need to customize in contat form 7 plugin core files.

= Do users need to do any customization to set different field form signup form?

No, I believe in very quick solution and hence I make people reach out of any customizations.

= Can we use it multiple Forms in single page? =

Yes, you can use it in multiple forms. Every from has different option and you can set fields for each and every forms although if it is in single page.

== Screenshots ==
1. Screenshot 'screenshot-1.png' Shows 'registration settings' tab in contact form edit section.
2. Screenshot 'screenshot-2.png' Shows User Role change option in settings.

== Changelog ==

= 4.5 =
* Tested with latest Contact Form 7 & WP.
* Fix: Solve some minor bugs.

= 4.4 =
* Tested with latest Contact Form 7 with major update by them.
* Tested with latest WordPress version.

= 4.3 =
* Set Option for Login URL Enable/Disable and Custom URL.

= 4.2 =
* Solved Redirection issue and tested with latest WP version.

= 4.1 =
* Solved some issue related to Site Health.

= 4.0 =
* Add New Feature of AutoLogin. After Registration its auto login and redirect on Home Page.

= 3.3 =
* Changes in GUI of Registration Setting and changes in some variable to make compitible with another plugin.

= 3.1 =
* Changes in GUI of Registration Setting with Contact form 7

= 3.0 =
* Add New feature for Free version , Now you can Skip defaul Contact form 7 Email.

= 2.1 =
* Add New feature for PRO version , Update detail in Free Plugin for Information.

= 2.0 =
* Add New feature for add user role from admin

= 1.0 =
* Initial Release