<?php get_header(); ?>

<div class="container pt-5">
  <div class="title pb-5">
      <h2 class="text-center">Loading custom post type content dynamically</h2>
  </div>
  <div class="row">
      <div class="col-sm-4">
          <ul id="post_title">

          </ul>
      </div>

      <div class="col-sm-8">
          <div class="post_content_render">
              <h4>load your post here</h4>
          </div>
      </div>
  </div>
</div>


<?php get_footer(); ?>
