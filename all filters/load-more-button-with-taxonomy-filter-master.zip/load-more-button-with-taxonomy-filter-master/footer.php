<!-- <div class="brand"> <a href="https://www.aylinmarie.co"><img src="https://static1.squarespace.com/static/56c5196f4c2f85dda57c1d66/t/58debb8be58c62f81cbf17d7/1494191752948/"></a></div> -->

        <!-- <footer>
        <p>designed and developed by <a href="http://www.aylinmarie.co">Aylin Marie</a> // Implemented with <a href="https://isotope.metafizzy.co/">Isotope</a></p>
      </footer> -->

<!-- jQuery library -->
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->

<!-- Popper JS -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script> -->

<!-- Latest compiled JavaScript -->
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> -->

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.isotope/3.0.6/isotope.pkgd.min.js"></script> -->

<!-- <script src="js/main.js">  </script> -->

<?php wp_footer(); ?>


<script type="text/javascript">
    var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
    var page =2;
    jQuery(function($){
        // init isotope
        var $grid = $('.grid');
        $grid.isotope({
          // options
          itemSelector: '.grid-item',
          percentPosition: true,
        });

        $('body').on('click', '.loadmore', function(e){

          var data = {
            'action': 'load_posts_by_ajax',
            'page': page,
            'security': '<?php echo wp_create_nonce("load_more_posts"); ?>'
          };

          $.post(ajaxurl, data, function(response){
            if (response != '') {
              var $answer = $(response);

              //append items to grid
              $grid.append($answer)
              .isotope('appended', $answer);

              // layaout on imagesLoaded
              $grid.imagesLoaded(function(){
                $grid.isotope('layout');
              });
              page++;
            } else{
              $('.loadmore').text("No more Post!");
              $('.loadmore').attr("disabled", true);
              $('.loadmore').css("borderColor", "gray");
              $('.loadmore').css("color", "gray");
            }
          });
          e.preventDefault();
        });
    });
</script>
</body>
</html>
