<main>
	@include('pages.forgotten-password.form')
	@include('components.contact')
</main>
