<main>
	@include('pages.register.form')
	@include('components.contact')
</main>
