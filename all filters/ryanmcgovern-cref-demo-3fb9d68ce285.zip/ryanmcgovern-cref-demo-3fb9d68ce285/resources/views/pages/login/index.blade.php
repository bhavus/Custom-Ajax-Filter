<main>
	@include('pages.login.form')
	@include('components.contact')
</main>
