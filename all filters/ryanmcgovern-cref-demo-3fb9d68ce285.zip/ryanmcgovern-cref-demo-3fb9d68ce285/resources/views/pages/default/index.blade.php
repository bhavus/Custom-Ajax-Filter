<main>
	@include('pages.default.content')
	@include('components.contact')
</main>
