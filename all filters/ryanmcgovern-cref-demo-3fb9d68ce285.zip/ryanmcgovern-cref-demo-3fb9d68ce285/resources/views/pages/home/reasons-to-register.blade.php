<section>
	Reasons to register
</section>